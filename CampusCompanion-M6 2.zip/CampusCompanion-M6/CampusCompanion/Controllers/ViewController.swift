//
//  ViewController.swift
//  CampusCompanion
//
//  Created by JHONN ARMILLO on 10/17/26.
//

import UIKit
import PhotosUI


private enum DefaultsKey {
    static let studentName = "studentName"
    static let notificationsEnabled = "notificationsEnabled"
    static let selectedRoleIndex = "selectedRoleIndex"
}

class ViewController: UIViewController, PHPickerViewControllerDelegate {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!

    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var changePhotoButton: UIButton!
    @IBOutlet weak var removePhotoButton: UIButton!

    // A single filename is shared by saving, loading, and removal.
    private let profilePhotoFilename = "profilePhoto.jpg"
    private var isLoadingProfileImage = false

    private var profilePhotoURL: URL? {
        guard let documentsURL = FileManager.default.urls(
            for: .documentDirectory, in: .userDomainMask
        ).first else { return nil }
        return documentsURL.appendingPathComponent(profilePhotoFilename)
    }

    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var notifySwitch: UISwitch!
    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!

    
    @IBOutlet weak var eventDatePicker: UIDatePicker!
    @IBOutlet weak var guestsStepper: UIStepper!
    @IBOutlet weak var guestsCountLabel: UILabel!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.backButtonTitle = "Back"
        // Ensure initial text matches the requirements
        titleLabel.text = "Campus Companion"
        subtitleLabel.text = "Your Campus, In Your Pocket"

        // Event dates cannot be in the past
        eventDatePicker.minimumDate = Date()
        guestsCountLabel.text = "\(Int(guestsStepper.value))"

        // Exercise 4, Part 1: restore persisted values (safe defaults on first launch)
        nameTextField.text = UserDefaults.standard.string(forKey: DefaultsKey.studentName) ?? ""
        notifySwitch.isOn = UserDefaults.standard.bool(forKey: DefaultsKey.notificationsEnabled)
        roleSegmentedControl.selectedSegmentIndex =
            UserDefaults.standard.integer(forKey: DefaultsKey.selectedRoleIndex)

        loadProfileImageFromDisk()
        profileImageView.isAccessibilityElement = true
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        profileImageView.layer.cornerRadius = profileImageView.bounds.width / 2
        profileImageView.clipsToBounds = true
    }

    

    @IBAction func changePhotoTapped(_ sender: UIButton) {
        guard !isLoadingProfileImage else { return }
        nameTextField.resignFirstResponder()
        var configuration = PHPickerConfiguration()
        configuration.filter = .images
        configuration.selectionLimit = 1
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = self
        present(picker, animated: true)
    }

    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        // Dismiss even when Cancel produces an empty result.
        // Wait for dismissal before loading so even an immediate failure can show an alert.
        picker.dismiss(animated: true) { [weak self] in
            guard let provider = results.first?.itemProvider else { return }
            self?.loadSelectedProfilePhoto(from: provider)
        }
    }

    private func loadSelectedProfilePhoto(from provider: NSItemProvider) {
        guard provider.canLoadObject(ofClass: UIImage.self) else {
            reportPhotoError("The selected item could not be opened as an image.")
            return
        }

        // Prevent another selection or removal racing with this asynchronous load.
        isLoadingProfileImage = true
        updatePhotoButtons()
        provider.loadObject(ofClass: UIImage.self) { [weak self] object, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                self.isLoadingProfileImage = false
                defer { self.updatePhotoButtons() }

                if let error = error {
                    self.reportPhotoError("Could not load the selected photo: \(error.localizedDescription)")
                    return
                }
                guard let image = object as? UIImage else {
                    self.reportPhotoError("The selected photo did not contain a readable image.")
                    return
                }
                if self.saveProfileImageToDisk(image) {
                    self.showProfileImage(image)
                }
            }
        }
    }

    @discardableResult
    private func saveProfileImageToDisk(_ image: UIImage) -> Bool {
        guard let fileURL = profilePhotoURL else {
            reportPhotoError("The Documents directory is unavailable.")
            return false
        }
        guard let data = image.jpegData(compressionQuality: 0.8) else {
            reportPhotoError("The selected photo could not be converted to JPEG.")
            return false
        }
        do {
            // Atomic replacement keeps the previous photo intact if the write fails.
            try data.write(to: fileURL, options: .atomic)
            return true
        } catch {
            reportPhotoError("Could not save the profile photo: \(error.localizedDescription)")
            return false
        }
    }

    private func loadProfileImageFromDisk() {
        if let fileURL = profilePhotoURL,
           let image = UIImage(contentsOfFile: fileURL.path) {
            showProfileImage(image)
        } else {
            showProfilePlaceholder()
        }
        updatePhotoButtons()
    }

   

    @IBAction func removePhotoTapped(_ sender: UIButton) {
        guard !isLoadingProfileImage else { return }
        guard let fileURL = profilePhotoURL else {
            reportPhotoError("The Documents directory is unavailable.")
            updatePhotoButtons()
            return
        }
        guard FileManager.default.fileExists(atPath: fileURL.path) else {
            showProfilePlaceholder()
            updatePhotoButtons()
            return
        }
        do {
            try FileManager.default.removeItem(at: fileURL)
            showProfilePlaceholder()
        } catch {
            // Keep showing the existing photo if its file could not be deleted.
            reportPhotoError("Could not remove the profile photo: \(error.localizedDescription)")
        }
        updatePhotoButtons()
    }

    private func updatePhotoButtons() {
        let hasSavedPhoto = profilePhotoURL.map {
            FileManager.default.fileExists(atPath: $0.path)
        } ?? false
        changePhotoButton.isEnabled = !isLoadingProfileImage
        removePhotoButton.isEnabled = hasSavedPhoto && !isLoadingProfileImage
    }

    private func showProfileImage(_ image: UIImage) {
        profileImageView.contentMode = .scaleAspectFill
        profileImageView.image = image
        profileImageView.accessibilityLabel = "Student profile photo"
    }

    private func showProfilePlaceholder() {
        profileImageView.contentMode = .scaleAspectFit
        profileImageView.image = UIImage(systemName: "person.crop.circle")
        profileImageView.accessibilityLabel = "No profile photo"
    }

    private func reportPhotoError(_ message: String) {
        print("Profile photo: \(message)")
        // A slow provider may complete after the student navigates to another screen.
        guard viewIfLoaded?.window != nil,
              navigationController?.topViewController === self,
              presentedViewController == nil else { return }
        let alert = UIAlertController(title: "Profile Photo", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    
    @IBAction func exploreButtonTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()
        let enteredName = nameTextField.text ?? ""

        // Exercise 4, Part 1: save captured values before the segue runs
        UserDefaults.standard.set(enteredName, forKey: DefaultsKey.studentName)
        UserDefaults.standard.set(notifySwitch.isOn, forKey: DefaultsKey.notificationsEnabled)
        UserDefaults.standard.set(roleSegmentedControl.selectedSegmentIndex,
                                  forKey: DefaultsKey.selectedRoleIndex)

        performSegue(withIdentifier: "ShowDetailSegue", sender: self)
    }

    // Exercise 4, Part 3: clear saved values and reset the fields immediately
    @IBAction func resetPreferencesTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()

        UserDefaults.standard.removeObject(forKey: DefaultsKey.studentName)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.notificationsEnabled)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.selectedRoleIndex)

        nameTextField.text = ""
        notifySwitch.setOn(false, animated: true)
        roleSegmentedControl.selectedSegmentIndex = 0
    }

    @IBAction func guestsStepperChanged(_ sender: UIStepper) {
        guestsCountLabel.text = "\(Int(sender.value))"
    }

  
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Only the "Explore Campus" segue carries data. The "Campus Announcements"
        // segue has no identifier and is ignored here.
        guard segue.identifier == "ShowDetailSegue",
              let destination = segue.destination as? DetailViewController else {
            return
        }

        let enteredName = nameTextField.text?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        destination.studentName = enteredName.isEmpty ? "Student" : enteredName
        destination.notificationsEnabled = notifySwitch.isOn
        destination.selectedRole = roleSegmentedControl.selectedSegmentIndex == 0
            ? "Student" : "Faculty"
        destination.eventDate = eventDatePicker.date
        destination.guestCount = max(Int(guestsStepper.value), 1)
    }
}
