# Parts 1–3 verification

## Changes delivered

- `ViewController.swift`: photo picker delegate, fixed Documents JPEG path, save/load methods, Remove Photo action, placeholder, saved-file-based button state, main-queue updates, and file-error handling. Restored the existing title outlet.
- `DetailViewController.swift`: retained location manager, explicit authorization handling, one-shot location request, original campus coordinate, named nearby library coordinate, two titled annotations, map fitting, visible markers, and distance in meters to the original campus only.
- `Main.storyboard`: image outlet, connected Change Photo and Remove Photo buttons, map outlet, distance-label outlet, and scrollable detail layout.
- `Info.plist`: specific When In Use location explanation.

## Checks completed in this workspace

Static checks cover XML and property-list parsing, unique storyboard IDs, connection destinations, controller outlet/action matches, constraint references, required feature wiring, original-campus distance references, source/build-resource membership, unchanged unrelated app sources, and ZIP integrity. Coordinate math independently places the example library about 124 meters from the original campus.

Xcode, Apple's iOS SDK, and iOS Simulator are unavailable in this workspace. No iOS build, device execution, runtime persistence result, or screenshot is claimed. Complete the following checks in Xcode before submitting.

## Photo checklist — run in Xcode

- [ ] Build with Command+B and run with Command+R.
- [ ] Fresh install: neutral `person.crop.circle` placeholder appears; Remove Photo is disabled.
- [ ] Change Photo presents the system picker and permits only one image selection.
- [ ] Cancel with no saved photo leaves the placeholder and disabled button intact.
- [ ] Selecting a photo displays it and enables Remove Photo after a successful save.
- [ ] Selecting another photo replaces the single `Documents/profilePhoto.jpg` file.
- [ ] Cancel with a saved photo leaves that image and file intact.
- [ ] Stop and relaunch the app without uninstalling: the saved image is restored.
- [ ] Remove Photo deletes `Documents/profilePhoto.jpg`, resets the placeholder, and disables Remove Photo.
- [ ] Stop and relaunch again: the removed photo stays removed.
- [ ] Select another photo after removal: save and removal still work.
- [ ] Existing name, notification, role, date, guest count, and navigation controls still work.

To inspect the actual file in Simulator, use **Device → Open Container → Data Container** when available, or run `xcrun simctl get_app_container booted edu.feutech.mad2.CampusCompanion data` in Terminal and inspect the returned `Documents` directory. There should be exactly one profile-photo file after saving and none after removing.

## Map and location checklist — run in Xcode

- [ ] Explore Campus shows the existing detail text followed by the map and distance label.
- [ ] Opening an announcement shows its existing details plus the same map and distance feature.
- [ ] Campus and Campus Library pins are both visible on opening; their titles differ.
- [ ] Tap each marker to inspect its title/callout; selecting either does not change distance.
- [ ] The map shows both landmarks even before location permission is granted.
- [ ] Allow When In Use access: a location result produces a distance in meters.
- [ ] Simulate campus `(14.6255, 121.0034)` before opening: distance is near zero.
- [ ] Simulate library `(14.6263, 121.0042)` before opening: distance is about 124 meters to campus.
- [ ] Deny access: the label explains how to enable it in Settings; both pins remain visible.
- [ ] Grant access later in Settings: returning to the app updates the authorization state and requests a location.
- [ ] If restrictions apply, the label clearly reports restricted access.
- [ ] With no available location, the label reports unavailability; choose a simulated location and reopen to retry.
- [ ] Small iPhone, landscape, and long announcement: scroll to reach all content, and both pins fit after rotation.
- [ ] Existing announcement add, refresh, delete, persistence, and detail navigation still work.

The library coordinate is an example near the guide's campus coordinate. It does not assert the real location of a campus library.

## Suggested genuine screenshots

Capture these from the running app after completing the checklist:

1. A chosen profile photo with Remove Photo enabled.
2. The placeholder after removal, with Remove Photo disabled.
3. Both campus markers and a granted-location distance in meters.

No screenshots are included because the app could not be run here.
